'use strict';
(()=>{
const get=id=>document.getElementById(id);let games=[],loaded=false,loading=false,shown=48,current=null,timer=null,request=null,launch=0;
function safe(value){try{const u=new URL(value);return u.origin==='https://gn-math.dev'&&u.pathname.startsWith('/s/')?u.href:null;}catch{return null;}}
function render(){const query=get('games-query').value.trim().toLowerCase(),filtered=games.filter(g=>(g.name+' '+g.author).toLowerCase().includes(query));get('games-grid').replaceChildren();for(const game of filtered.slice(0,shown)){const card=document.createElement('button');card.className='game-card';card.title=game.name;card.onclick=()=>open(game);const cover=safe(game.cover);if(cover){const img=document.createElement('img');img.src=cover;img.alt='';img.loading='lazy';img.referrerPolicy='no-referrer';img.onerror=()=>img.remove();card.append(img);}const name=document.createElement('strong');name.textContent=game.name;card.append(name);get('games-grid').append(card);}get('games-more').hidden=filtered.length<=shown;if(!loading)get('games-status').textContent=filtered.length?filtered.length+' games · GN-Math':loaded?'No matching games.':'';}
async function load(){if(loading)return;loading=true;get('games-refresh').disabled=true;get('games-status').textContent='Loading games…';try{const r=await fetch('/api/games',{signal:AbortSignal.timeout(25000)}),d=await r.json();if(!r.ok)throw new Error(d.error||'Could not load games.');games=(d.games||[]).filter(g=>typeof g.name==='string'&&safe(g.url));loaded=true;loading=false;render();}catch(e){get('games-status').textContent=e.name==='TimeoutError'?'Games took too long to load. Tap reload to retry.':e.message;}finally{loading=false;get('games-refresh').disabled=false;}}
function prepareGame(html,url){
 const doc=new DOMParser().parseFromString(html,'text/html');
 const originalBase=doc.querySelector('base[href]');let baseURL=url;
 if(originalBase){try{baseURL=new URL(originalBase.getAttribute('href'),url).href;}catch{}}
 doc.querySelectorAll('base').forEach(n=>n.remove());
 const base=doc.createElement('base');base.href=baseURL;doc.head.prepend(base);
 // This document runs in an opaque sandbox, never with Crowprox's origin.
 const guard=doc.createElement('script');guard.textContent=`
 window.open=()=>null;
 // Opaque frames cannot use browser storage. Supply session-only game saves.
 for(const name of ['localStorage','sessionStorage']){const data=new Map();const api={getItem:k=>data.has(String(k))?data.get(String(k)):null,setItem:(k,v)=>data.set(String(k),String(v)),removeItem:k=>data.delete(String(k)),clear:()=>data.clear(),key:i=>Array.from(data.keys())[i]??null,get length(){return data.size}};try{Object.defineProperty(window,name,{value:api});}catch{}}
 document.addEventListener('click',event=>{const a=event.target.closest?.('a[href]');if(a&&!a.getAttribute('href').startsWith('#')){event.preventDefault();event.stopImmediatePropagation();}},true);
 window.addEventListener('error',event=>{if(event.message&&event.message!=='Script error.'){parent.postMessage({type:'crowprox-game-error'},'*');}});
 `;base.after(guard);
 doc.querySelectorAll('meta[http-equiv]').forEach(n=>{if(n.httpEquiv.toLowerCase()==='refresh')n.remove();});
 return '<!doctype html>'+doc.documentElement.outerHTML;
}
async function open(game){
 clearTimeout(timer);request?.abort();request=new AbortController();const token=++launch;current=game;
 get('games-library').hidden=true;get('game-player').hidden=false;get('game-name').textContent=game.name;get('game-host').replaceChildren();get('game-status').textContent='Loading '+game.name+'…';
 const controller=request;const deadline=setTimeout(()=>controller.abort(),25000);
 try{
  const url=safe(game.url);if(!url)throw new Error('This game has an invalid address.');
  const response=await fetch(url,{signal:controller.signal,credentials:'omit',referrerPolicy:'no-referrer'});
  if(!response.ok)throw new Error('This game is unavailable right now. Try another game or Reload.');
  const html=await response.text();if(html.length>20000000)throw new Error('This game is too large for the embedded player.');
  if(!/<(?:html|script|canvas|body|iframe)\b/i.test(html))throw new Error('The game server returned an invalid game file.');
  if(token!==launch)return;
  const frame=document.createElement('iframe');frame.title=game.name;frame.allow='autoplay; fullscreen; gamepad';frame.allowFullscreen=true;
  frame.setAttribute('sandbox','allow-scripts allow-pointer-lock');frame.referrerPolicy='no-referrer';
  frame.onload=()=>{if(token===launch){clearTimeout(timer);get('game-status').textContent='';}};
  frame.srcdoc=prepareGame(html,url);get('game-host').replaceChildren(frame);
  timer=setTimeout(()=>{if(token===launch)get('game-status').textContent='This game is taking a while. Try Reload or choose another game.';},20000);
 }catch(e){if(token===launch)get('game-status').textContent=e.name==='AbortError'?'The game took too long to download. Try Reload.':e.message;}
 finally{clearTimeout(deadline);}
}
function close(){launch++;request?.abort();request=null;clearTimeout(timer);current=null;get('game-host').replaceChildren();get('game-player').hidden=true;get('games-library').hidden=false;}
window.addEventListener('message',event=>{const frame=get('game-host').querySelector('iframe');if(frame&&event.source===frame.contentWindow&&event.data?.type==='crowprox-game-error'){clearTimeout(timer);get('game-status').textContent='This game reported a problem. If it stays blank, try Reload or choose another game.';}});
get('games-query').oninput=()=>{shown=48;render();};get('games-refresh').onclick=load;get('games-more').onclick=()=>{shown+=48;render();};get('game-close').onclick=close;get('game-reload').onclick=()=>{if(current)open(current);};get('game-fullscreen').onclick=async()=>{try{await get('game-host').requestFullscreen();}catch{get('game-status').textContent='Fullscreen is unavailable in this browser.';}};
new MutationObserver(()=>{if(document.body.dataset.page==='games'){if(!loaded&&!loading)load();}else if(current)close();}).observe(document.body,{attributes:true,attributeFilter:['data-page']});if(document.body.dataset.page==='games')load();window.addEventListener('pagehide',close);window.crowproxIcons?.();
})();
