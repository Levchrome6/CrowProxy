'use strict';
(()=>{
 const get=id=>document.getElementById(id);const apple=()=>get('catalog-source').value==='apple';let tracks=[],saved=readSaved('crowded-saved-music',[]),mode='discover',nextOffset=null,request=null,loaded=false,playing=null;
 const valid=t=>t&&typeof t.id==='string'&&/^[a-zA-Z0-9]{1,40}$/.test(t.id)&&typeof t.name==='string'&&typeof t.artist==='string'&&t.catalog===true;
 saved=Array.isArray(saved)?saved.filter(valid).slice(0,200):[];
 const safeURL=value=>{try{const url=new URL(value);return url.protocol==='https:'?url.href:null;}catch{return null;}};
 function save(){persist('crowded-saved-music',saved);get('saved-track-count').textContent=String(saved.length);}
 function render(){
  const grid=get('catalog-grid');grid.replaceChildren();get('discover-tab').setAttribute('aria-pressed',String(mode==='discover'));get('saved-tracks-tab').setAttribute('aria-pressed',String(mode==='saved'));
  const query=get('catalog-query').value.toLowerCase(),items=mode==='saved'?saved.filter(t=>(!query||(t.name+' '+t.artist).toLowerCase().includes(query))&&(!get('catalog-genre').value||t.genre===get('catalog-genre').value)):tracks;
  get('catalog-heading').textContent=mode==='saved'?'Your saved tracks':query?'Search results':apple()?'Find your favorites':'Trending this week';
  get('source-note').textContent=apple()?'Apple Music: search mainstream releases. Official player offers previews when signed out; full tracks require an eligible subscription and sign-in.':'Audius: full-length public streams, no music subscription required. Availability varies by artist.';
  get('catalog-genre').disabled=apple();get('catalog-trending').textContent=apple()?'Clear search':'Trending';
  get('catalog-credit').textContent=apple()?'Discovery metadata from Apple’s search API. Playback is provided by the official Apple Music player. Availability varies by region.':'Full tracks provided by Audius. Saved favorites stay on this device.';
  for(const track of items){
   const card=document.createElement('article');card.className='catalog-card'+(playing===track.id?' active':'');
   const cover=document.createElement('button');cover.className='catalog-cover';cover.setAttribute('aria-label','Play '+track.name+' by '+track.artist);cover.onclick=()=>window.CrowdedSound.add(track,true);
   const art=safeURL(track.artwork);if(art){const img=document.createElement('img');img.src=art;img.alt='';img.loading='lazy';img.referrerPolicy='no-referrer';img.onerror=()=>img.remove();cover.append(img);}
   if(track.provider==='apple'){const initials=document.createElement('b');initials.className='artist-initials';initials.textContent=track.artist.split(' ').map(s=>s[0]).join('').slice(0,2);cover.append(initials);cover.classList.add('apple-cover');}
   const play=document.createElement('span');play.textContent=playing===track.id?'♫':'▶';cover.append(play);card.append(cover);
   const badge=document.createElement('small');badge.className='track-badge';badge.textContent=track.provider==='apple'?'APPLE MUSIC · PREVIEW / SUBSCRIPTION':'AUDIUS · FULL TRACK';card.append(badge);
   const title=document.createElement('h3');title.textContent=track.name;title.title=track.name;const artist=document.createElement('p');artist.textContent=track.artist;card.append(title,artist);
   const actions=document.createElement('div');actions.className='catalog-actions';
   const favorite=document.createElement('button'),isSaved=saved.some(t=>t.id===track.id);favorite.textContent=isSaved?'♥':'♡';favorite.setAttribute('aria-label',(isSaved?'Unsave ':'Save ')+track.name);favorite.setAttribute('aria-pressed',String(isSaved));favorite.onclick=()=>{if(isSaved)saved=saved.filter(t=>t.id!==track.id);else{if(saved.length>=200){get('catalog-status').textContent='You can save up to 200 tracks.';return;}saved.push(track);}save();render();};
   const add=document.createElement('button');add.textContent='+ Queue';add.setAttribute('aria-label','Add '+track.name+' to queue');add.onclick=()=>window.CrowdedSound.add(track);
   const source=document.createElement('a');source.textContent='↗';source.title=track.provider==='apple'?'Open in Apple Music':'View on Audius';source.setAttribute('aria-label','View '+track.name+(track.provider==='apple'?' on Apple Music':' on Audius'));const link=safeURL(track.permalink);source.href=link&&['audius.co','music.apple.com'].includes(new URL(link).hostname)?link:'https://audius.co';source.target='_blank';source.rel='noopener noreferrer';if(track.provider==='apple'){source.textContent='Apple Music ↗';actions.append(favorite,source);}else actions.append(favorite,add,source);card.append(actions);grid.append(card);
  }
  if(!items.length&&!request){const empty=document.createElement('p');empty.className='catalog-empty';empty.textContent=mode==='saved'?'Save tracks with the heart button to find them here.':apple()?'Search for an artist or song above, or choose a suggestion.':'No publicly streamable tracks found. Try another artist or genre.';grid.append(empty);}
  get('catalog-more').hidden=mode==='saved'||nextOffset===null;get('catalog-more').disabled=!!request;
 }
 async function load(more=false){
  request?.abort();const controller=new AbortController();request=controller;mode='discover';loaded=true;
  if(!more){tracks=[];nextOffset=null;}get('catalog-status').textContent='Loading music…';get('catalog-grid').setAttribute('aria-busy','true');render();
  const params=new URLSearchParams({q:get('catalog-query').value.trim(),genre:get('catalog-genre').value,offset:String(more?nextOffset||0:0)});
  const timeout=setTimeout(()=>controller.abort(),16000);
  try{const response=await fetch((apple()?'/api/music/apple?':'/api/music?')+params,{signal:controller.signal});const data=await response.json();if(!response.ok)throw new Error(data.error||'Music search failed.');if(request!==controller)return;
   const incoming=Array.isArray(data.tracks)?data.tracks.filter(valid):[];const seen=new Set(tracks.map(t=>t.id));tracks.push(...incoming.filter(t=>!seen.has(t.id)));nextOffset=Number.isInteger(data.nextOffset)?data.nextOffset:null;get('catalog-status').textContent=tracks.length+(apple()?' tracks · open in Apple’s player':' tracks · click artwork to play')+(tracks.length?'':'. Try another search or load more.');
  }catch(e){if(request!==controller)return;get('catalog-status').textContent=e.name==='AbortError'?'Music search timed out. Press Search to retry.':e.message;}
  finally{clearTimeout(timeout);if(request===controller){request=null;get('catalog-grid').setAttribute('aria-busy','false');render();}}
 }
 get('catalog-source').onchange=()=>{get('catalog-genre').value='';load();};
 document.querySelectorAll('[data-music-query]').forEach(button=>button.onclick=()=>{get('catalog-query').value=button.dataset.musicQuery;load();});
 get('catalog-form').onsubmit=e=>{e.preventDefault();if(mode==='saved')render();else load();};get('catalog-genre').onchange=()=>mode==='saved'?render():load();
 get('catalog-trending').onclick=()=>{get('catalog-query').value='';get('catalog-genre').value='';load();};get('discover-tab').onclick=()=>load();get('saved-tracks-tab').onclick=()=>{request?.abort();request=null;mode='saved';get('catalog-status').textContent='Saved on this device.';get('catalog-grid').setAttribute('aria-busy','false');render();};get('catalog-more').onclick=()=>load(true);
 window.addEventListener('crowded-track',event=>{playing=event.detail;render();});
 new MutationObserver(()=>{if(document.body.dataset.page==='music'&&!loaded)load();}).observe(document.body,{attributes:true,attributeFilter:['data-page']});save();render();if(document.body.dataset.page==='music')load();
})();
