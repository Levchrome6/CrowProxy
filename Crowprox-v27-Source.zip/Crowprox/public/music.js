'use strict';
(()=>{
 const get=id=>document.getElementById(id),audio=get('sound-audio');let queue=[],current=-1,shuffle=false,repeat=false;
 const say=text=>get('music-status').textContent=text;
 function render(){
  get('queue-count').textContent=String(queue.length);const list=get('track-list');list.replaceChildren();
  const query=get('queue-search').value.toLowerCase();
  queue.forEach((track,index)=>{if(!track.name.toLowerCase().includes(query))return;const row=document.createElement('div');row.className='track-row'+(index===current?' playing':'');const play=document.createElement('button');play.textContent=(index===current?'♫  ':String(index+1).padStart(2,'0')+'  ')+track.name;play.onclick=()=>select(index);const remove=document.createElement('button');remove.textContent='×';remove.setAttribute('aria-label','Remove '+track.name);remove.onclick=()=>{const active=index===current;if(active){audio.pause();audio.removeAttribute('src');audio.load();}if(track.local)URL.revokeObjectURL(track.url);queue.splice(index,1);if(index<current)current--;else if(active)current=-1;if(active&&queue.length)select(Math.min(index,queue.length-1));else if(!queue.length)reset();render();};row.append(play,remove);list.append(row);});
  if(!list.childNodes.length){const p=document.createElement('p');p.className='queue-empty';p.textContent=queue.length?'No matching tracks.':'Nothing queued yet. Add a few favorites.';list.append(p);}
 }
 function clearEmbed(){get('apple-player').replaceChildren();get('apple-player').hidden=true;audio.hidden=false;document.querySelector('.sound-controls').hidden=false;get('now-source').hidden=true;}
 function showArtwork(track){const img=get('now-art'),record=document.querySelector('.record-art');img.hidden=true;record.hidden=false;img.removeAttribute('src');if(track?.artwork){try{const u=new URL(track.artwork);if(u.protocol==='https:'){img.src=u.href;img.hidden=false;record.hidden=true;img.onerror=()=>{img.hidden=true;record.hidden=false;};}}catch{}}}
 function reset(){clearEmbed();showArtwork(null);current=-1;audio.pause();audio.removeAttribute('src');audio.load();get('track-title').textContent='Make some room for music.';get('track-source').textContent='LOCAL FILES + AUDIO LINKS';get('music-dock').hidden=true;document.querySelector('.record-art').classList.remove('spinning');if('mediaSession'in navigator){navigator.mediaSession.metadata=null;navigator.mediaSession.playbackState='none';}}
 async function play(){try{await audio.play();}catch(e){say('Playback could not start. Press Play, or try another audio file.');}}
 function select(index){if(!queue[index])return;current=index;const track=queue[index];clearEmbed();showArtwork(track);audio.src=track.url;get('track-title').textContent=track.name;get('track-source').textContent=track.catalog?'AUDIUS · '+track.artist:track.local?'FROM YOUR DEVICE':'DIRECT AUDIO LINK';get('return-music').textContent='♫ '+track.name;get('music-dock').hidden=false;say(track.catalog?'Streaming from Audius · '+track.artist:track.local?'Playing from your device. No upload.':'Streaming directly from the audio host.');if('mediaSession'in navigator&&'MediaMetadata'in window)navigator.mediaSession.metadata=new MediaMetadata({title:track.name,artist:track.artist||'Crowded Sound'});render();play();window.dispatchEvent(new CustomEvent('crowded-track',{detail:track.id||null}));}
 function next(delta=1,ended=false){if(!queue.length)return;if(ended&&repeat){audio.currentTime=0;play();return;}if(shuffle&&queue.length>1){let n=Math.floor(Math.random()*(queue.length-1));if(n>=current)n++;select(n);return;}const n=current+delta;if(ended&&n>=queue.length){say('End of queue. Choose a track to play again.');return;}select((n+queue.length)%queue.length);}
 get('music-add').onclick=()=>get('music-files').click();get('music-files').onchange=e=>{let count=0;for(const file of e.target.files){if(queue.length>=100){say('Queue limit: 100 tracks.');break;}if(!file.type.startsWith('audio/')&&!/\.(mp3|m4a|wav|ogg|flac|aac)$/i.test(file.name))continue;queue.push({name:file.name.replace(/\.[^.]+$/,''),url:URL.createObjectURL(file),local:true});count++;}render();if(current<0&&count)select(queue.length-count);get('music-files').value='';};
 get('music-url-form').onsubmit=e=>{e.preventDefault();try{if(queue.length>=100)throw new Error('Queue limit: 100 tracks.');const url=new URL(get('music-url').value);if(url.protocol!=='https:'||url.username||url.password)throw new Error('Use a public HTTPS audio URL.');if(/(^|\.)(youtube\.com|youtu\.be|spotify\.com|music\.apple\.com)$/.test(url.hostname))throw new Error('Use an audio file or stream URL, not a streaming-service page.');let name=url.pathname.split('/').filter(Boolean).pop()||url.hostname;try{name=decodeURIComponent(name);}catch{}queue.push({name:name.slice(0,160),url:url.href,local:false});get('music-url').value='';render();if(current<0)select(queue.length-1);}catch(e){say(e.message);}};
 get('queue-search').oninput=render;get('queue-clear').onclick=()=>{reset();queue.forEach(t=>{if(t.local)URL.revokeObjectURL(t.url);});queue=[];render();say('Queue cleared.');};get('sound-next').onclick=()=>next();get('sound-prev').onclick=()=>next(-1);
 get('sound-shuffle').onclick=()=>{shuffle=!shuffle;get('sound-shuffle').setAttribute('aria-pressed',String(shuffle));};get('sound-repeat').onclick=()=>{repeat=!repeat;get('sound-repeat').setAttribute('aria-pressed',String(repeat));};
 get('dock-stop').onclick=()=>{audio.pause();if(!get('apple-player').hidden){clearEmbed();get('music-dock').hidden=true;say('Apple Music player stopped. Select a song to reopen.');}};audio.addEventListener('ended',()=>next(1,true));audio.addEventListener('error',()=>say('This audio could not load. The format may be unsupported, or the host may block playback. Try a local file or another direct link.'));
 for(const type of ['play','pause'])audio.addEventListener(type,()=>{document.querySelector('.record-art').classList.toggle('spinning',!audio.paused);if('mediaSession'in navigator)navigator.mediaSession.playbackState=audio.paused?'paused':'playing';});
 if('mediaSession'in navigator){for(const [name,handler]of Object.entries({play,pause:()=>audio.pause(),nexttrack:()=>next(),previoustrack:()=>next(-1),seekto:d=>{if(Number.isFinite(d.seekTime)&&Number.isFinite(audio.duration))audio.currentTime=Math.min(audio.duration,Math.max(0,d.seekTime));}})){try{navigator.mediaSession.setActionHandler(name,handler);}catch{}}}
 window.CrowdedSound={add(track,start=false){
  if(track?.provider==='apple'){
   let url;try{url=new URL(track.permalink);}catch{return;}
   if(url.protocol!=='https:'||url.hostname!=='music.apple.com')return;
   audio.pause();audio.removeAttribute('src');audio.load();clearEmbed();showArtwork(null);current=-1;render();
   get('track-title').textContent=track.name;get('track-source').textContent='APPLE MUSIC · '+track.artist;
   const link=get('now-source');link.href=url.href;link.hidden=false;
   url.hostname='embed.music.apple.com';url.searchParams.set('theme','dark');
   const player=document.createElement('iframe');player.src=url.href;player.title='Apple Music: '+track.name;player.allow='autoplay; encrypted-media; fullscreen';player.referrerPolicy='strict-origin-when-cross-origin';
   get('apple-player').append(player);get('apple-player').hidden=false;audio.hidden=true;document.querySelector('.sound-controls').hidden=true;
   get('return-music').textContent='♫ '+track.name;get('music-dock').hidden=false;
   if('mediaSession'in navigator){navigator.mediaSession.metadata=null;navigator.mediaSession.playbackState='none';}
   say('Use Apple’s player below. Signed-out playback is a short preview; full songs require an eligible subscription. Apple tracks do not use the Audius queue.');
   window.dispatchEvent(new CustomEvent('crowded-track',{detail:track.id}));
   document.querySelector('.now-playing').scrollIntoView({behavior:'smooth',block:'nearest'});return;
  }

  if(!track||!track.catalog||! /^[a-zA-Z0-9]{1,40}$/.test(track.id))return;
  let index=queue.findIndex(t=>t.id===track.id);
  if(index<0){if(queue.length>=100){say('Queue limit: 100 tracks. Remove a track first.');return;}queue.push({...track,url:'https://api.audius.co/v1/tracks/'+track.id+'/stream?app_name=CrowdedBrowser',local:false});index=queue.length-1;}
  render();if(start)select(index);else say('Added to queue: '+track.name);
 }};
 window.addEventListener('pagehide',()=>{audio.pause();});render();
})();
