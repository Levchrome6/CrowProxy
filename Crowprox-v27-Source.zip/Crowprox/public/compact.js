"use strict";
// Layout controls only; browsing and network setup are unchanged.
const sidebarToggle=document.getElementById('sidebar-toggle');
sidebarToggle.onclick=()=>{const closed=document.body.classList.toggle('sidebar-collapsed');sidebarToggle.setAttribute('aria-expanded',String(!closed));};
const toolbar=document.querySelector('nav');
['bookmark-current','reopen-tab','history-open'].forEach(id=>toolbar.append(document.getElementById(id)));
document.getElementById('new-tab').textContent='+  New tab';
if(!readSaved('crowded-compact-layout',false)){
 setAccent('lime');persist('crowded-accent','lime');
 homeOptions.theme='forest';persist('crowded-home-v1',homeOptions);applyHome();
 persist('crowded-compact-layout',true);
}
