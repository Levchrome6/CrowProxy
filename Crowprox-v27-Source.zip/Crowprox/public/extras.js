'use strict';
let localHistory=readSaved('crowded-history-v1',[]);
if(!Array.isArray(localHistory))localHistory=[];
localHistory=localHistory.filter(item=>{try{return typeof item.title==='string'&&typeof item.time==='number'&&!!bookmarkURL(item.url);}catch{return false;}}).slice(0,100);
let historyEnabled=false;
$('save-history').checked=historyEnabled;
function recordVisit(){}
function renderHistory(){
  const query=$('history-search').value.trim().toLowerCase();$('history-list').replaceChildren();
  $('history-note').textContent=historyEnabled?'Up to 100 pages, stored only on this device.':'History is off. Turn it on in Settings to remember future pages.';
  const items=localHistory.filter(item=>(item.title+' '+item.url).toLowerCase().includes(query));
  if(!items.length){const empty=document.createElement('p');empty.className='dialog-intro';empty.textContent='No pages to show.';$('history-list').append(empty);}
  for(const item of items){
    const button=document.createElement('button');button.className='history-item';
    const title=document.createElement('strong');title.textContent=item.title;
    const sub=document.createElement('span');sub.textContent=new URL(item.url).hostname+' · '+new Date(item.time).toLocaleDateString();
    button.append(title,sub);button.onclick=()=>{$('history-dialog').close();browse(item.url);};$('history-list').append(button);
  }
}
$('history-open').onclick=()=>{renderHistory();$('history-dialog').showModal();};
$('history-search').oninput=renderHistory;
$('save-history').onchange=e=>{historyEnabled=e.target.checked;persist('crowded-save-history',historyEnabled);$('data-status').textContent=historyEnabled?'History is on for future visits.':'History is off. Use Clear history to erase saved visits.';};
$('clear-history').onclick=()=>{localHistory=[];persist('crowded-history-v1',[]);$('data-status').textContent='History cleared.';renderHistory();};
$('reopen-tab').onclick=()=>{
 if(workspaceTabs.length>=12){tell('Close a tab first.');return;}
 const closed=closedTabs.pop();if(!closed){tell('No recently closed tabs in this session.');return;}
 newBrowserTab();browse(closed.url);
};
function importBookmarkData(data,existing){
 const list=Array.isArray(data)?data:data?.bookmarks;
 if(!Array.isArray(list)||list.length>150)throw new Error('Choose a bookmark JSON file with up to 150 entries.');
 const next=[...existing];let added=0;
 for(const item of list){
  if(!item||typeof item.name!=='string'||!item.name.trim()||typeof item.url!=='string')throw new Error('Every bookmark needs a name and website URL.');
  const url=bookmarkURL(item.url);
  if(next.some(b=>b.url===url))continue;
  if(next.length>=150)throw new Error('Import would exceed 150 bookmarks. Remove a few first.');
  next.push({id:crypto.randomUUID(),name:item.name.trim().slice(0,70),url,folder:FOLDERS.includes(item.folder)?item.folder:'Favorites'});added++;
 }
 return {bookmarks:next,added};
}
$('export-bookmarks').onclick=()=>{
 const blob=new Blob([JSON.stringify({version:1,bookmarks:bookmarks.map(({name,url,folder})=>({name,url,folder}))},null,2)],{type:'application/json'});
 const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='crowded-bookmarks.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);$('data-status').textContent='Bookmark export downloaded.';
};
$('import-bookmarks').onclick=()=>$('bookmark-file').click();
$('bookmark-file').onchange=async e=>{
 try{const file=e.target.files[0];if(!file)return;if(file.size>200000)throw new Error('Choose a JSON file smaller than 200 KB.');
 const result=importBookmarkData(JSON.parse(await file.text()),bookmarks);bookmarks=result.bookmarks;saveBookmarks();$('data-status').textContent=result.added+' bookmarks imported. Duplicates skipped.';
 }catch(error){$('data-status').textContent=error.message;}finally{e.target.value='';}
};
let backdrop=readSaved('crowded-backdrop','stars');
if(!['stars','landscape','plain','grid'].includes(backdrop))backdrop='stars';
try{if(localStorage.getItem('crowded-night-style')!=='v1'){backdrop='stars';setAccent('purple');persist('crowded-accent','purple');persist('crowded-backdrop',backdrop);localStorage.setItem('crowded-night-style','v1');}}catch{}
document.body.dataset.backdrop=backdrop;$('home-backdrop').value=backdrop;
$('customize-form').addEventListener('submit',()=>{backdrop=$('home-backdrop').value;document.body.dataset.backdrop=backdrop;persist('crowded-backdrop',backdrop);});
$('reset-home').addEventListener('click',()=>{backdrop='stars';document.body.dataset.backdrop=backdrop;$('home-backdrop').value=backdrop;persist('crowded-backdrop',backdrop);});
function diagnosticText(){
 const tab=activeTab();let host='No website';try{host=new URL(tab.url).hostname;}catch{}
 return 'Website: '+host+'\nTransport: '+selectedTransport+'\nSecure context: '+isSecureContext+'\nService worker: '+(navigator.serviceWorker?.controller?'active':'not controlling this page')+'\nConnection state: '+$('state').textContent;
}
function updateDiagnostics(){
 const tab=activeTab();const isTikTok=!!tab?.url&&/(^|\.)tiktok\.com$/.test(new URL(tab.url).hostname);
 $('page-help-summary').textContent=isTikTok?'If TikTok shows Wisp error 0x42, the Wisp server cannot reach TikTok. Changing transport will not fix that server error. Open original to try TikTok directly. Other playback errors may depend on browser media support.':'If this page fails to load, try reloading it or switching the network transport.';
 $('page-diagnostics').textContent=diagnosticText();
 $('open-original').href=tab?.url||'https://www.tiktok.com/';$('diagnostic-status').textContent='';
}
$('page-help').onclick=()=>{updateDiagnostics();$('page-help-dialog').showModal();};
$('retry-page').onclick=()=>{activeTab()?.instance?.reload();$('page-help-dialog').close();};
$('alternate-transport').onclick=async()=>{
 const button=$('alternate-transport');button.disabled=true;const previous=selectedTransport,next=previous==='libcurl'?'epoxy':'libcurl';
 try{await ready;await limit(connection.setTransport(...transportSettings(next,wisp)),20000,'Transport change timed out. Reload the app to restore your saved transport.');
 selectedTransport=next;$('proxy-transport').value=next;try{localStorage.setItem('crowded-transport',next);}catch{}
 activeTab()?.instance?.reload();updateDiagnostics();$('diagnostic-status').textContent='Now using '+next+'. Current page reloaded.';
 }catch(e){$('diagnostic-status').textContent=e.message;}finally{button.disabled=false;}
};
$('copy-diagnostics').onclick=async()=>{try{await navigator.clipboard.writeText(diagnosticText());$('diagnostic-status').textContent='Copied. Share this along with a screenshot of the error.';}catch{$('diagnostic-status').textContent='Copy unavailable. You can select the diagnostic text above.';}};
document.querySelectorAll('#history-dialog [data-close],#page-help-dialog [data-close]').forEach(button=>button.onclick=()=>$(button.dataset.close).close());
