'use strict';
const $ = id => document.getElementById(id);
const DEFAULT_WISP = 'wss://wisp.mercurywork.shop/';
let wisp = DEFAULT_WISP;
try { wisp = localStorage.getItem('crowded-wisp') || DEFAULT_WISP; } catch {}
$('wisp').value = wisp;
let selectedTransport = 'libcurl';
try {
  if (localStorage.getItem('crowded-transport-default') !== 'libcurl-v1') {
    localStorage.setItem('crowded-transport', 'libcurl');
    localStorage.setItem('crowded-transport-default', 'libcurl-v1');
  }
  const savedTransport = localStorage.getItem('crowded-transport');
  if (savedTransport === 'epoxy' || savedTransport === 'libcurl') selectedTransport = savedTransport;
} catch {}
$('proxy-transport').value = selectedTransport;
function transportSettings(name, server) { return name === 'libcurl' ? ['/libcurl/index.mjs', [{websocket:server}]] : ['/epoxy/index.mjs', [{wisp:server}]]; }
let engine, connection, frame, ready, timeout, initialBrowserFrame;
const tell = message => { $('notice-text').textContent = message; $('notice').hidden = false; };
const limit = (promise, ms, label) => Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error(label)), ms))]);
function destination(value) {
  value = value.trim();
  if (!value) return null;
  if (/^[a-z][a-z\d+.-]*:/i.test(value) && !/^https?:/i.test(value)) throw new Error('Please enter an HTTP or HTTPS website.');
  if (/^https?:\/\//i.test(value)) return new URL(value).href;
  if (/^[^\s/]+\.[^\s]+/.test(value) || /^localhost(?::\d+)?(?:\/|$)/.test(value)) return new URL('https://' + value).href;
  return searchBase() + encodeURIComponent(value);
}
async function initialize() {
  if (!isSecureContext) throw new Error('Browsing needs a secure browser context. Open the full HTTPS site directly in your browser. Local development also works on localhost.');
  if (!('serviceWorker' in navigator)) throw new Error('Service workers are unavailable in this browser or embedded view. Scramjet needs them to browse websites. Try opening the full HTTPS site directly in a supported browser tab.');
  if (typeof $scramjetLoadController !== 'function' || typeof BareMux === 'undefined') throw new Error('Proxy files could not load. Refresh the page and try again.');
  const { ScramjetController } = $scramjetLoadController();
  engine = new ScramjetController({ prefix: '/service/', files: { wasm: '/scram/scramjet.wasm.wasm', all: '/scram/scramjet.all.js', sync: '/scram/scramjet.sync.js' } });
  await engine.init();
  await navigator.serviceWorker.register('/sw.js');
  await navigator.serviceWorker.ready;
  if (!navigator.serviceWorker.controller) await new Promise(resolve => navigator.serviceWorker.addEventListener('controllerchange', resolve, { once: true }));
  connection = new BareMux.BareMuxConnection('/baremux/worker.js');
  await connection.setTransport(...transportSettings(selectedTransport,wisp));
  frame = engine.createFrame();
  initialBrowserFrame = frame;
  frame.frame.title = 'Proxied website';
  $('viewport').appendChild(frame.frame);
  const initialFrame = frame;
  frame.frame.addEventListener('load', () => {
    if (frame !== initialFrame) return;
    clearTimeout(timeout); $('state').textContent = 'Page loaded';
    try { const value = engine.decodeUrl(frame.frame.contentWindow.location.href); if (/^https?:/.test(value)) $('address').value = value; } catch {}
  });
  $('state').textContent = 'Ready to browse';
}
async function browse(value) {
  try {
    const url = destination(value); if (!url) return;
    $('notice').hidden = true; $('state').textContent = 'Preparing…';
    await ready;
    browserHasPage = true; showPage('browser'); $('address').value = url;
    $('state').textContent = 'Loading…'; frame.go(url);
    clearTimeout(timeout); timeout = setTimeout(() => tell('This page is taking a while. Try another website or use Settings → Test connection to check the Wisp server.'), 25000);
  } catch(error) { $('state').textContent = 'Connection issue'; tell(error.message); }
}
$('address-form').onsubmit = event => { event.preventDefault(); browse($('address').value); };
$('search-form').onsubmit = event => { event.preventDefault(); browse($('search').value); };
document.querySelectorAll('[data-url]').forEach(button => button.onclick = () => browse(button.dataset.url));
$('home').onclick = () => { clearTimeout(timeout); browserHasPage = false; showPage('browser'); $('address').value = ''; $('search').focus(); };
$('reload').onclick = () => { if (frame && !$('viewport').hidden) frame.reload(); else location.reload(); };
$('back').onclick = () => { if (frame && !$('viewport').hidden) frame.back(); };
$('forward').onclick = () => { if (frame && !$('viewport').hidden) frame.forward(); };
$('fullscreen').onclick = async () => { try { if(document.fullscreenElement) await document.exitFullscreen(); else await document.documentElement.requestFullscreen(); } catch { tell('Full screen is unavailable in this browser.'); } };
$('dismiss').onclick = () => $('notice').hidden = true;

function serverValue() { const u = new URL($('wisp').value.trim()); if(u.protocol !== 'wss:') throw new Error('Use a secure WebSocket URL beginning with wss://.'); return u.href; }
$('save').onclick = async () => {
  const button=$('save');button.disabled=true;
  try {
    const next=serverValue(),nextTransport=$('proxy-transport').value;
    await ready;
    await limit(connection.setTransport(...transportSettings(nextTransport,next)),20000,'The transport did not respond. Refresh and select the original Epoxy transport if needed.');
    wisp=next;selectedTransport=nextTransport;
    try {localStorage.setItem('crowded-wisp',wisp);localStorage.setItem('crowded-transport',selectedTransport);} catch {}
    $('test-result').textContent='Saved '+(selectedTransport==='libcurl'?'libcurl':'Epoxy')+'. Reload open websites to use this connection.';
  } catch(error) {$('test-result').textContent=error.message;}
  finally {button.disabled=false;}
};
$('test').onclick = async () => {
  let socket, timer; $('test').disabled = true; $('test-result').textContent = 'Connecting…';
  try { const url = serverValue(); await new Promise((resolve,reject) => { socket = new WebSocket(url); timer = setTimeout(() => reject(new Error('Connection timed out. The Wisp server may be unavailable.')), 10000); socket.onopen = resolve; socket.onerror = () => reject(new Error('Unable to connect. Check the server URL and network.')); }); $('test-result').textContent = 'WebSocket connection succeeded. Website loading still depends on Wisp compatibility and destination availability.'; }
  catch(error) { $('test-result').textContent = error.message; }
  finally { clearTimeout(timer); if(socket) socket.close(); $('test').disabled = false; }
};
ready = limit(initialize(), 20000, 'Proxy setup timed out. Refresh the page; service workers and shared workers must be enabled.');
ready.then(()=>document.dispatchEvent(new CustomEvent('crowprox-ready')),()=>{});
ready.catch(error => {document.dispatchEvent(new CustomEvent('crowprox-boot-error'));  $('state').textContent = 'Setup issue'; tell(error.message); });
document.addEventListener('keydown', event => { if((event.ctrlKey || event.metaKey) && event.key === 'l') { event.preventDefault(); $('address').focus(); $('address').select(); } });
// App sections and device-local preferences.
let browserHasPage = false;
const readSaved = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
const persist = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch { tell('Your browser could not save this preference. It will last for this session.'); } };
const colors = {lime:'#b9f6d5',blue:'#91baff',purple:'#c9abff',pink:'#ffabc9'};
const searchEngines = {google:'https://www.google.com/search?q=',duckduckgo:'https://duckduckgo.com/?q=',bing:'https://www.bing.com/search?q='};
let selectedEngine = readSaved('crowded-search','google');
if (!Object.hasOwn(searchEngines,selectedEngine)) selectedEngine = 'google';
function searchBase() { return searchEngines[selectedEngine]; }
function showPage(page) {
  $('movies-page').hidden=page!=='movies';
  $('games-page').hidden=page!=='games';document.body.dataset.page = page; document.body.dataset.hasPage = String(browserHasPage); 
  $('ai-page').hidden = page !== 'ai'; $('settings-page').hidden = page !== 'settings';
  $('start').hidden = page !== 'browser' || browserHasPage;
  $('viewport').hidden = page !== 'browser' || !browserHasPage;
  document.querySelectorAll('[data-page]').forEach(button => { if(button.tagName === 'BUTTON') button.setAttribute('aria-pressed', String(button.dataset.page === page)); });
}
document.querySelectorAll('button[data-page]').forEach(button => button.onclick = () => showPage(button.dataset.page));
function setAccent(name) { if (!Object.hasOwn(colors,name)) name = 'lime'; document.documentElement.style.setProperty('--accent',colors[name]); document.querySelectorAll('[data-accent]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.accent === name))); }
setAccent(readSaved('crowded-accent','lime'));
document.querySelectorAll('[data-accent]').forEach(button => button.onclick = () => { setAccent(button.dataset.accent); persist('crowded-accent',button.dataset.accent); });
$('search-engine').value = selectedEngine;
$('search-engine').onchange = event => { selectedEngine = event.target.value; persist('crowded-search',selectedEngine); };
showPage('browser');

let seed = 47;
const random = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
for (let i=0;i<95;i++) { const star=document.createElement('i'); star.style.left=random()*100+'%';star.style.top=random()*100+'%';star.style.opacity=.15+random()*.55;star.style.setProperty('--delay',random()*8+'s'); if(i%17===0) star.className='shooting'; $('starfield').appendChild(star); }
function setMotion(on) { document.body.classList.toggle('still-stars',!on); $('star-motion').checked=on; }
setMotion(readSaved('crowded-star-motion',true));
$('star-motion').onchange = event => { setMotion(event.target.checked);persist('crowded-star-motion',event.target.checked); };
