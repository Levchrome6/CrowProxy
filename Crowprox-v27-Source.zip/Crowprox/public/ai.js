'use strict';
(() => {
  let pipWindow=null;
  const get=id=>pipWindow?.document.getElementById(id)||document.getElementById(id),log=get('ai-messages'),input=get('ai-input'),error=get('ai-error'),status=get('attachment-status'),video=get('screen-video');
  let messages=[],pending=[],controller=null,stream=null,processing=false,sharingPending=false;
  const fail=message=>{error.textContent=message;error.hidden=false;};
  function updateControls(){
    const busy=!!controller;
    get('ai-send').disabled=busy||processing;get('ai-stop').hidden=!busy;get('ai-clear').disabled=busy||processing;
    get('ai-attach').disabled=busy||processing;get('ai-screen').disabled=busy||sharingPending;
    input.disabled=busy;
    get('ai-send').textContent=busy?'Thinking…':'Send ↗';log.setAttribute('aria-busy',String(busy));get('ai-model').disabled=busy;window.crowproxIcons?.(pipWindow?.document||document);
  }
  function renderPending(){
    get('ai-attachments').replaceChildren();
    pending.forEach((file,index)=>{
      const card=document.createElement('div');card.className='attachment-card';
      if(file.kind==='image'){const image=document.createElement('img');image.src=file.data;image.alt='Pending attachment: '+file.name;card.append(image);}
      const label=document.createElement('span');label.textContent=file.name;card.append(label);
      if(file.kind==='text'){const preview=document.createElement('details'),summary=document.createElement('summary'),text=document.createElement('pre');summary.textContent='Preview text';text.textContent=file.text;preview.append(summary,text);card.append(preview);}
      const remove=document.createElement('button');remove.type='button';remove.textContent='×';remove.disabled=!!controller;remove.setAttribute('aria-label','Remove '+file.name);remove.onclick=()=>{pending.splice(index,1);renderPending();};card.append(remove);get('ai-attachments').append(card);
    });
  }
  function render(){
    log.replaceChildren();
    if(!messages.length){
      const welcome=document.createElement('div');welcome.className='ai-welcome';
      const title=document.createElement('h2');title.textContent='How can I help?';
      const desc=document.createElement('p');desc.textContent='';welcome.append(title,desc);
      for(const text of []){const b=document.createElement('button');b.textContent=text;b.onclick=()=>{input.value=text;input.focus();};welcome.append(b);}
      log.append(welcome);
    }
    for(const m of messages){
      const item=document.createElement('article');item.className='ai-message '+m.role;
      const name=document.createElement('strong');name.textContent=m.role==='user'?'You':'Crowprox';
      const content=document.createElement('div');content.textContent=m.content;item.append(name,content);
      if(m.role==='assistant'){
        const copy=document.createElement('button');copy.className='copy-answer';copy.textContent='Copy';copy.onclick=async()=>{try{await navigator.clipboard.writeText(m.content);copy.textContent='Copied';setTimeout(()=>copy.textContent='Copy',1500);}catch{copy.textContent='Select text to copy';}};item.append(copy);
      }
      if(m.files?.length){const labels=document.createElement('small');labels.className='message-files';labels.textContent='Attached: '+m.files.map(f=>f.name).join(', ');item.append(labels);}
      log.append(item);
    }
    log.scrollTop=log.scrollHeight;
  }
  function imageData(source,width,height){
    if(!width||!height)throw new Error('The image is not ready yet. Try again.');
    const ratio=Math.min(1,1600/Math.max(width,height)),canvas=document.createElement('canvas');
    canvas.width=Math.round(width*ratio);canvas.height=Math.round(height*ratio);
    const context=canvas.getContext('2d');context.fillStyle='#fff';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(source,0,0,canvas.width,canvas.height);
    let data=canvas.toDataURL('image/jpeg',.82);
    if(data.length>1600000)data=canvas.toDataURL('image/jpeg',.58);
    if(data.length>1600000)throw new Error('This image is too detailed. Crop it or choose a smaller image.');
    return data;
  }
  async function readImage(file){
    const url=URL.createObjectURL(file);
    try{const image=new Image();image.src=url;await image.decode();return imageData(image,image.naturalWidth,image.naturalHeight);}
    finally{URL.revokeObjectURL(url);}
  }
  async function readPDF(file){
    const pdfjs=await import('/pdfjs/pdf.mjs');pdfjs.GlobalWorkerOptions.workerSrc='/pdfjs/pdf.worker.mjs';
    const task=pdfjs.getDocument({data:new Uint8Array(await file.arrayBuffer()),isEvalSupported:false,standardFontDataUrl:"/pdfjs/standard_fonts/",cMapUrl:"/pdfjs/cmaps/",cMapPacked:true});
    const timeout=setTimeout(()=>task.destroy(),20000);
    try{
      const pdf=await task.promise;if(pdf.numPages>40)throw new Error('PDFs can contain up to 40 pages. Upload a shorter extract.');
      let text='';
      for(let n=1;n<=pdf.numPages;n++){const page=await pdf.getPage(n),content=await page.getTextContent();text+='\n[Page '+n+']\n'+content.items.map(item=>typeof item.str==='string'?item.str:'').join(' ');if(text.length>20000)throw new Error('This PDF has too much text. Use an extract under 20,000 characters.');}
      if(text.replace(/\[Page \d+\]/g,'').trim().length<5)throw new Error('This PDF has no readable text. Attach a screenshot of the page instead.');
      return text.trim();
    }catch(e){if(e.name==='PasswordException')throw new Error('This PDF is password protected. Use an unlocked copy.');throw e;}
    finally{clearTimeout(timeout);await task.destroy();}
  }
  async function addFiles(files){
    if(processing||controller)return;
    error.hidden=true;processing=true;updateControls();
    try{
      for(const file of files){
        if(pending.length>=3)throw new Error('Attach up to 3 files at once.');
        if(file.size>10*1024*1024)throw new Error(file.name+' exceeds the 10 MB file limit.');
        status.textContent='Preparing '+file.name+'…';
        const name=file.name.slice(0,180),ext=name.split('.').pop().toLowerCase();let entry;
        if(['png','jpg','jpeg','webp'].includes(ext))entry={name,kind:'image',data:await readImage(file)};
        else if(ext==='pdf')entry={name,kind:'text',text:await readPDF(file)};
        else if(['txt','md','csv','json','js','ts','tsx','jsx','py','lua','html','css','xml','yaml','yml','log'].includes(ext)){
          if(file.size>100000)throw new Error('Text files must be under 100 KB.');
          const text=await file.text();if(text.includes('\u0000'))throw new Error('This file contains binary data. Choose a text document.');entry={name,kind:'text',text};
        }else throw new Error('Use PNG, JPG, WebP, a text PDF, or a text/code file. Word, ZIP, audio, and video files are not supported.');
        if(entry.kind==='text'&&(!entry.text.trim()||entry.text.length>20000))throw new Error('Documents must contain 1–20,000 characters.');
        if(entry.kind==='text'&&pending.reduce((sum,f)=>sum+(f.text?.length||0),entry.text.length)>40000)throw new Error('Keep attached documents under 40,000 characters combined.');
        pending.push(entry);renderPending();
      }
      status.textContent='Ready. Attachments are sent only when you press Send.';
    }catch(e){status.textContent='';fail(e.message||'Could not read that file.');}
    finally{processing=false;get('ai-files').value='';updateControls();}
  }
  get('ai-attach').onclick=()=>get('ai-files').click();
  get('ai-files').onchange=e=>addFiles(Array.from(e.target.files||[]));
  input.addEventListener('paste',e=>{const files=Array.from(e.clipboardData?.files||[]);if(files.length){e.preventDefault();addFiles(files);}});
  get('ai-page').addEventListener('dragover',e=>{if(e.dataTransfer.types.includes('Files'))e.preventDefault();});
  get('ai-page').addEventListener('drop',e=>{if(e.dataTransfer.files.length){e.preventDefault();addFiles(Array.from(e.dataTransfer.files));}});
  function stopSharing(){
    const old=stream;stream=null;if(old)old.getTracks().forEach(track=>track.stop());
    video.srcObject=null;get('screen-panel').hidden=true;get('ai-screen').textContent='Share screen';status.textContent='Screen sharing stopped. New messages will not include your screen.';
  }
  get('ai-screen').onclick=async()=>{
    if(stream){stopSharing();return;}
    if(!navigator.mediaDevices?.getDisplayMedia){fail('Screen sharing is unavailable in this browser. You can attach a screenshot instead.');return;}
    error.hidden=true;sharingPending=true;updateControls();
    try{
      const selected=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false});
      if(document.body.dataset.page!=='ai'&&!pipWindow){selected.getTracks().forEach(t=>t.stop());return;}
      stream=selected;get('screen-panel').hidden=false;video.srcObject=stream;await video.play();
      stream.getVideoTracks()[0].addEventListener('ended',stopSharing,{once:true});
      get('ai-screen').textContent='Stop sharing';status.textContent='Screen connected. Every message automatically sends the current frame to AI.';
    }catch(e){stopSharing();fail(e.name==='NotAllowedError'?'Screen sharing was cancelled or not permitted. You can attach a screenshot instead.':'Could not start screen sharing. Try a supported browser or attach a screenshot.');}
    finally{sharingPending=false;updateControls();}
  };
  get('screen-end').onclick=stopSharing;
  get('ai-float').onclick=async()=>{
    if(pipWindow){pipWindow.close();return;}
    if(!window.documentPictureInPicture){fail('Floating AI is unavailable in this browser. You can still share your screen and chat here.');return;}
    try{
      const win=await window.documentPictureInPicture.requestWindow({width:440,height:650});
      pipWindow=win;win.document.title='Crowprox · screen companion';
      document.querySelectorAll('link[rel="stylesheet"]').forEach(link=>{const copy=win.document.createElement('link');copy.rel='stylesheet';copy.href=link.href;win.document.head.append(copy);});
      win.document.body.className='ai-pip';
      const root=document.getElementById('ai-page'),panel=win.document.createElement('section');panel.id='ai-floating';
      while(root.firstChild)panel.append(root.firstChild);
      win.document.body.append(panel);
      const note=document.createElement('p');note.id='pip-note';note.textContent='AI is open in the floating window. Close that window to bring it back.';root.append(note);
      get('ai-float').textContent='Return to browser';
      win.addEventListener('pagehide',()=>{stopSharing();root.replaceChildren(...panel.childNodes);pipWindow=null;get('ai-float').textContent='Float AI ↗';showPage('ai');},{once:true});
    }catch(e){fail('Could not open the floating window. Try again from the main AI tab.');}
  };
  new MutationObserver(()=>{if(document.body.dataset.page!=='ai'&&!pipWindow)stopSharing();}).observe(document.body,{attributes:true,attributeFilter:['data-page']});
  window.addEventListener('pagehide',stopSharing);
  get('ai-form').onsubmit=async event=>{
    event.preventDefault();if(controller||processing)return;
    const content=input.value.trim()||(stream?'Help me understand what is on my screen.':pending.length?'Help me understand these attachments.':'');if(!content)return;
    error.hidden=true;const files=[...pending];
    if(stream){
      try{
        if(files.length>=3)throw new Error('While sharing, attach up to 2 files to leave room for your screen.');
        files.push({name:'Current screen '+new Date().toLocaleTimeString(),kind:'image',data:imageData(video,video.videoWidth,video.videoHeight),liveScreen:true});
      }catch(e){fail(e.message);return;}
    }
    pending=[];
    messages.push({role:'user',content,files:files.map(f=>({name:f.name}))});render();input.value='';controller=new AbortController();updateControls();renderPending();
    const timer=setTimeout(()=>controller?.abort(),55000);
    try{
      const conversation=messages.slice(-19).map(m=>({role:m.role,content:m.content.slice(0,m.role==='assistant'?16000:3300)+(m!==messages[messages.length-1]&&m.files?.length?'\n[Earlier attachments not resent: '+m.files.map(f=>f.name).join(', ')+']':'')}));
      const response=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:conversation,attachments:files,model:get('ai-model').value}),signal:controller.signal});
      const data=await response.json();if(!response.ok)throw new Error(data.error||'Could not send. Try again.');
      messages.push({role:'assistant',content:data.message});if(messages.length>40)messages=messages.slice(-40);render();status.textContent=stream?'Screen connected · the next message includes a fresh frame.':'';
    }catch(e){messages.pop();pending=files.filter(f=>!f.liveScreen);render();renderPending();input.value=content;fail(e.name==='AbortError'?'Response stopped. Your message and attachments are ready to resend.':e.message);}
    finally{clearTimeout(timer);controller=null;updateControls();renderPending();input.focus();}
  };
  get('ai-stop').onclick=()=>controller?.abort();
  get('ai-clear').onclick=()=>{messages=[];pending=[];stopSharing();status.textContent='';error.hidden=true;render();renderPending();input.focus();};
  input.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();get('ai-form').requestSubmit();}};
  render();updateControls();
  fetch('/api/models').then(async response=>{const data=await response.json();if(!response.ok)throw new Error(data.error||'Models unavailable');for(const model of data.models||[]){const option=document.createElement('option');option.value=model.id;option.textContent=model.label;get('ai-model').append(option);}}).catch(()=>{get('ai-model').title='Model list unavailable. Auto is still available.';});
  if(new URLSearchParams(location.search).get('section')==='ai')showPage('ai');
})();
