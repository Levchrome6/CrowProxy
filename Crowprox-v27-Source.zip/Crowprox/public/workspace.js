'use strict';
// Browsing tabs use the existing controller; the proxy configuration stays in app.js.
const HOME_DEFAULTS = {name:'',theme:'forest',layout:'cards',clock:true,shortcuts:true,bookmarks:true};
const closedTabs=[];
const FOLDERS = ['Favorites','Games','Music','School','Other'];
function bookmarkURL(value) {
  value = String(value).trim();
  if (!/^https?:\/\//i.test(value)) value = 'https://' + value;
  const u = new URL(value);
  if (!['http:','https:'].includes(u.protocol) || u.username || u.password || !u.hostname.includes('.') && u.hostname !== 'localhost') throw new Error('Enter a valid HTTP or HTTPS website address.');
  return u.href;
}
function selectedAfterClose(tabs, id, active) {
  const index=tabs.findIndex(tab=>tab.id===id),remaining=tabs.filter(tab=>tab.id!==id);
  return {remaining,active:active===id ? remaining[Math.min(index,remaining.length-1)]?.id || null : active};
}
const workspaceTabs=[];
let nextTab=1, activeTabId=null, spareFrame=null, editingBookmark=null, homeOptions={...HOME_DEFAULTS};
let storedHome=readSaved('crowded-home-v1',{});
if(storedHome && typeof storedHome === 'object' && !Array.isArray(storedHome)) homeOptions={...HOME_DEFAULTS,...storedHome};
if(typeof homeOptions.name!=='string')homeOptions.name='';
homeOptions.name=homeOptions.name.slice(0,30);
if(!['forest','midnight','ocean','plum'].includes(homeOptions.theme))homeOptions.theme='forest';
if(!['cards','compact'].includes(homeOptions.layout))homeOptions.layout='cards';
let bookmarks=readSaved('crowded-bookmarks-v1',[]);
if(!Array.isArray(bookmarks))bookmarks=[];
bookmarks=bookmarks.filter(b=>{try{return typeof b.id==='string' && typeof b.name==='string' && FOLDERS.includes(b.folder) && !!bookmarkURL(b.url);}catch{return false;}}).slice(0,150);
const activeTab=()=>workspaceTabs.find(t=>t.id===activeTabId);
function renderTabs() {
  $('browser-tabs').replaceChildren();
  workspaceTabs.forEach(tab=>{
    const wrap=document.createElement('div');wrap.className='browser-tab'+(tab.id===activeTabId?' active':'');
    const button=document.createElement('button');button.className='tab-select';button.id='tab-'+tab.id;button.setAttribute('role','tab');button.setAttribute('aria-selected',String(tab.id===activeTabId));button.setAttribute('aria-controls',tab.url?'viewport':'start');button.textContent=tab.title;button.title=tab.url||'Home';button.onclick=()=>activateTab(tab.id);
    const close=document.createElement('button');close.className='tab-close';close.textContent='×';close.setAttribute('aria-label','Close '+tab.title);close.onclick=()=>closeTab(tab.id);wrap.append(button,close);$('browser-tabs').append(wrap);
  });
  $('new-tab').disabled=workspaceTabs.length>=12;
  $('new-tab').title=workspaceTabs.length>=12?'12-tab limit reached':'New tab';
  const tab=activeTab();$('bookmark-current').disabled=!tab?.url;
  const saved=bookmarks.some(b=>b.url===tab?.url);$('bookmark-current').textContent=saved?'★':'☆';$('bookmark-current').title=saved?'Edit bookmark':'Bookmark current page';
}
function activateTab(id) {
  const tab=workspaceTabs.find(t=>t.id===id);if(!tab)return;
  activeTabId=id;browserHasPage=!!tab.url;
  workspaceTabs.forEach(t=>{if(t.instance)t.instance.frame.hidden=t.id!==id || !t.url;});
  if(spareFrame)spareFrame.frame.hidden=true;
  frame=tab.instance||spareFrame;
  $('address').value=tab.url||'';showPage('browser');renderTabs();
}
function newBrowserTab() {
  if(workspaceTabs.length>=12){tell('Close a tab before opening another. You can keep up to 12 open.');return;}
  const tab={id:String(nextTab++),title:'New tab',url:null,instance:null,timer:null};workspaceTabs.push(tab);activateTab(tab.id);$('search').focus();
}
function closeTab(id) {
  const tab=workspaceTabs.find(t=>t.id===id);if(!tab)return;
  if(tab.url){closedTabs.push({url:tab.url,title:tab.title});if(closedTabs.length>10)closedTabs.shift();}
  clearTimeout(tab.timer);tab.instance?.frame.remove();
  const next=selectedAfterClose(workspaceTabs,id,activeTabId);workspaceTabs.splice(0,workspaceTabs.length,...next.remaining);
  if(!workspaceTabs.length)newBrowserTab();else activateTab(next.active);
}
function monitorFrame(tab) {
  const instance=tab.instance;
  instance.frame.allow='autoplay; fullscreen; picture-in-picture; encrypted-media';
  instance.frame.allowFullscreen=true;
  instance.frame.addEventListener('load',()=>{
    if(!workspaceTabs.includes(tab)||!tab.url)return;
    clearTimeout(tab.timer);
    try {
      const decoded=engine.decodeUrl(instance.frame.contentWindow.location.href);
      if(/^https?:\/\//.test(decoded))tab.url=decoded;
      const title=instance.frame.contentDocument?.title?.trim();if(title)tab.title=title.slice(0,70);
    }catch{}
    if(activeTabId===tab.id){$('address').value=tab.url;$('state').textContent='Page loaded';}
    if(typeof recordVisit==='function')recordVisit(tab);
    renderTabs();
  });
}
browse = async function(value) {
  const tab=activeTab();
  try {
    const url=destination(value);if(!url||!tab)return;
    $('notice').hidden=true;$('state').textContent='Preparing…';await ready;
    if(!workspaceTabs.includes(tab))return;
    if(!tab.instance){tab.instance=spareFrame||engine.createFrame();spareFrame=null;if(!tab.instance.frame.isConnected)$('viewport').append(tab.instance.frame);tab.instance.frame.title='Website in '+tab.title;monitorFrame(tab);}
    tab.url=url;tab.title=new URL(url).hostname;tab.instance.frame.hidden=activeTabId!==tab.id;
    if(activeTabId===tab.id){activateTab(tab.id);$('state').textContent='Loading…';}
    tab.instance.go(url);renderTabs();clearTimeout(tab.timer);
    tab.timer=setTimeout(()=>{if(activeTabId===tab.id)tell('This page is taking a while. Use the ? button beside the address bar to check the connection or try another transport.');},25000);
  }catch(error){$('state').textContent='Connection issue';tell(error.message);}
};
$('new-tab').onclick=newBrowserTab;
$('home').onclick=()=>{const tab=activeTab();clearTimeout(tab.timer);tab.url=null;tab.title='New tab';tab.instance?.frame.remove();tab.instance=null;activateTab(tab.id);$('search').focus();};
$('reload').onclick=()=>{const tab=activeTab();if(tab?.url&&tab.instance)tab.instance.reload();};
$('back').onclick=()=>activeTab()?.instance?.back();$('forward').onclick=()=>activeTab()?.instance?.forward();
ready.then(()=>{spareFrame=initialBrowserFrame;spareFrame.frame.hidden=true;}).catch(()=>{});
function saveBookmarks(){persist('crowded-bookmarks-v1',bookmarks);renderBookmarks();renderTabs();}
function openBookmarkEditor(item=null) {
  editingBookmark=item?.id||null;$('bookmark-dialog-title').textContent=item?.id?'Edit bookmark':'Add bookmark';
  $('bookmark-name').value=item?.name||'';$('bookmark-url').value=item?.url||'';$('bookmark-folder').value=item?.folder||'Favorites';$('bookmark-error').textContent='';$('bookmark-dialog').showModal();$('bookmark-name').focus();
}
$('add-bookmark').onclick=()=>openBookmarkEditor();
$('bookmark-current').onclick=()=>{const tab=activeTab();if(!tab?.url)return;const saved=bookmarks.find(b=>b.url===tab.url);openBookmarkEditor(saved||{name:tab.title,url:tab.url,folder:'Favorites'});};
$('bookmark-form').onsubmit=event=>{
  event.preventDefault();try{
    const url=bookmarkURL($('bookmark-url').value),name=$('bookmark-name').value.trim();if(!name)throw new Error('Give this bookmark a name.');
    const existing=bookmarks.find(b=>b.url===url&&b.id!==editingBookmark);if(existing)throw new Error('This website is already bookmarked. Edit the existing bookmark instead.');
    if(!editingBookmark&&bookmarks.length>=150)throw new Error('You have reached 150 bookmarks. Remove one before adding another.');
    const entry={id:editingBookmark||crypto.randomUUID(),name:name.slice(0,70),url,folder:$('bookmark-folder').value};
    if(editingBookmark)bookmarks=bookmarks.map(b=>b.id===editingBookmark?entry:b);else bookmarks.push(entry);
    saveBookmarks();$('bookmark-dialog').close();
  }catch(error){$('bookmark-error').textContent=error.message;}
};
function renderBookmarks() {
  const query=$('bookmark-search').value.toLowerCase().trim(),folder=$('bookmark-filter').value;
  const filtered=bookmarks.filter(b=>(!folder||b.folder===folder)&&(!query||(b.name+' '+b.url).toLowerCase().includes(query)));
  const grid=$('bookmark-grid');grid.replaceChildren();$('bookmark-count').textContent=bookmarks.length+' saved · stored on this device';
  if(!filtered.length){const empty=document.createElement('div');empty.className='bookmark-empty';empty.textContent=bookmarks.length?'No matching bookmarks. Try another search or folder.':'Your favorites belong here. Add a bookmark or star a page while browsing.';grid.append(empty);return;}
  filtered.forEach(item=>{
    const card=document.createElement('article');card.className='bookmark-card';
    const launch=document.createElement('button');launch.className='bookmark-launch';
    const icon=document.createElement('span');icon.className='bookmark-icon';icon.textContent=item.name.slice(0,1).toUpperCase();
    const info=document.createElement('span'),title=document.createElement('strong'),meta=document.createElement('small');title.textContent=item.name;meta.textContent=item.folder+' · '+new URL(item.url).hostname;info.append(title,meta);launch.append(icon,info);launch.onclick=()=>browse(item.url);
    const actions=document.createElement('div');actions.className='bookmark-actions';
    const open=document.createElement('button');open.textContent='↗';open.title='Open in a new tab';open.setAttribute('aria-label','Open '+item.name+' in new tab');open.onclick=()=>{if(workspaceTabs.length>=12){tell('Close a tab first.');return;}newBrowserTab();browse(item.url);};
    const edit=document.createElement('button');edit.textContent='Edit';edit.setAttribute('aria-label','Edit '+item.name);edit.onclick=()=>openBookmarkEditor(item);
    const remove=document.createElement('button');remove.textContent='×';remove.setAttribute('aria-label','Remove '+item.name);remove.onclick=()=>{bookmarks=bookmarks.filter(b=>b.id!==item.id);saveBookmarks();};actions.append(open,edit,remove);card.append(launch,actions);grid.append(card);
  });
}
$('bookmark-search').oninput=renderBookmarks;$('bookmark-filter').onchange=renderBookmarks;
function updateClock(){const date=new Date();$('home-clock').textContent=date.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});$('home-date').textContent=date.toLocaleDateString([],{weekday:'long',month:'long',day:'numeric'});}
function applyHome(){
  document.body.dataset.theme=homeOptions.theme;document.body.dataset.bookmarkLayout=homeOptions.layout;
  $('home-greeting').textContent='Crowprox';
  $('home-clock').hidden=!homeOptions.clock;$('home-date').hidden=!homeOptions.clock;
  document.querySelector('.shortcuts').hidden=!homeOptions.shortcuts;$('bookmark-section').hidden=!homeOptions.bookmarks;updateClock();
}
$('customize-home').onclick=()=>{
  $('home-name').value=homeOptions.name;$('home-theme').value=homeOptions.theme;$('home-layout').value=homeOptions.layout;$('home-accent').value=readSaved('crowded-accent','lime');
  $('home-showclock').checked=homeOptions.clock;$('home-showshortcuts').checked=homeOptions.shortcuts;$('home-showbookmarks').checked=homeOptions.bookmarks;$('customize-dialog').showModal();
};
$('customize-form').onsubmit=event=>{event.preventDefault();homeOptions={name:$('home-name').value.trim().slice(0,30),theme:$('home-theme').value,layout:$('home-layout').value,clock:$('home-showclock').checked,shortcuts:$('home-showshortcuts').checked,bookmarks:$('home-showbookmarks').checked};persist('crowded-home-v1',homeOptions);setAccent($('home-accent').value);persist('crowded-accent',$('home-accent').value);applyHome();$('customize-dialog').close();};
$('reset-home').onclick=()=>{homeOptions={...HOME_DEFAULTS};persist('crowded-home-v1',homeOptions);setAccent('lime');persist('crowded-accent','lime');applyHome();$('customize-dialog').close();};
document.querySelectorAll('[data-close]').forEach(button=>button.onclick=()=>$(button.dataset.close).close());
applyHome();renderBookmarks();newBrowserTab();setInterval(updateClock,30000);
