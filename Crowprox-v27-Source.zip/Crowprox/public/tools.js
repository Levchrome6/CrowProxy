'use strict';
(() => {
  const get=id=>document.getElementById(id);
  const safeSave=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}};
  const download=(text,name,type)=>{const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);};
  const openTools=()=>{renderSessions();get('tools-dialog').showModal();};
  get('tools-open').onclick=openTools;
  document.querySelectorAll('[data-tool-close]').forEach(button=>button.onclick=()=>get(button.dataset.toolClose).close());
  const note=readSaved('crowded-notes-v1','');
  get('scratchpad').value=typeof note==='string'?note.slice(0,10000):'';
  get('scratchpad').oninput=()=>{
    const ok=safeSave('crowded-notes-v1',get('scratchpad').value);
    get('note-status').textContent=ok?'Saved · '+get('scratchpad').value.length+'/10,000':'Could not save. Download your notes to keep them.';
  };
  get('download-notes').onclick=()=>download(get('scratchpad').value,'crowded-notes.txt','text/plain');

  let timer={remaining:25*60000,end:null,duration:25*60000};
  const savedTimer=readSaved('crowded-focus-v1',null);
  if(savedTimer && [5,15,25,45].includes(savedTimer.duration/60000) && Number.isFinite(savedTimer.remaining) && savedTimer.remaining>=0 && savedTimer.remaining<=savedTimer.duration && (savedTimer.end===null||Number.isFinite(savedTimer.end)))timer=savedTimer;
  get('focus-length').value=String(timer.duration/60000);
  const remaining=()=>timer.end===null?timer.remaining:Math.max(0,timer.end-Date.now());
  const saveTimer=()=>safeSave('crowded-focus-v1',timer);
  function renderTimer(){
    let ms=remaining();
    if(timer.end!==null&&ms===0){timer.end=null;timer.remaining=0;saveTimer();get('focus-status').textContent='Session complete. Take a moment to reset.';tell('Focus session complete. Take a break!');}
    const sec=Math.ceil(ms/1000),label=String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0');
    get('focus-clock').textContent=label;get('timer-badge').textContent=label;get('timer-badge').hidden=timer.end===null;
    get('focus-toggle').textContent=timer.end!==null?'Pause':timer.remaining===0?'Start again':timer.remaining<timer.duration?'Resume':'Start';
    get('focus-length').disabled=timer.end!==null;
  }
  get('focus-toggle').onclick=()=>{
    if(timer.end!==null){timer.remaining=remaining();timer.end=null;get('focus-status').textContent='Paused.';}
    else{if(timer.remaining===0)timer.remaining=timer.duration;timer.end=Date.now()+timer.remaining;get('focus-status').textContent='Running. You can close Tools and keep browsing.';}
    if(!saveTimer())get('focus-status').textContent+=' Timer cannot be saved in this browser.';
    renderTimer();
  };
  function resetTimer(){timer={duration:Number(get('focus-length').value)*60000,remaining:Number(get('focus-length').value)*60000,end:null};saveTimer();get('focus-status').textContent='Ready when you are.';renderTimer();}
  get('focus-reset').onclick=resetTimer;get('focus-length').onchange=resetTimer;
  renderTimer();setInterval(renderTimer,1000);

  let sessions=readSaved('crowded-sessions-v1',[]);
  if(!Array.isArray(sessions))sessions=[];
  sessions=sessions.filter(s=>s&&typeof s.id==='string'&&typeof s.name==='string'&&Array.isArray(s.tabs)&&s.tabs.length<=12&&s.tabs.every(t=>{try{return typeof t.title==='string'&&!!bookmarkURL(t.url);}catch{return false;}})).slice(0,8);
  function renderSessions(){
    const list=get('session-list');list.replaceChildren();
    if(!sessions.length){const p=document.createElement('p');p.className='dialog-intro';p.textContent='No saved sessions yet. Open a few websites, then save them here.';list.append(p);}
    sessions.forEach(session=>{
      const row=document.createElement('article');row.className='saved-session';
      const details=document.createElement('div'),name=document.createElement('strong'),meta=document.createElement('small');name.textContent=session.name;meta.textContent=session.tabs.length+' tabs · '+session.tabs.map(t=>new URL(t.url).hostname).join(', ');details.append(name,meta);
      const restore=document.createElement('button');restore.className='outline-button';restore.textContent='Open';restore.setAttribute('aria-label','Open session '+session.name);
      restore.onclick=async()=>{
        const reusable=workspaceTabs.find(t=>!t.url);
        if(workspaceTabs.length+session.tabs.length-(reusable?1:0)>12){get('session-status').textContent='Close some tabs first. This session needs '+session.tabs.length+' free slots (12 total).';return;}
        restore.disabled=true;
        try{await ready;get('tools-dialog').close();for(let i=0;i<session.tabs.length;i++){if(i===0&&reusable)activateTab(reusable.id);else newBrowserTab();await browse(session.tabs[i].url);}}
        catch(e){get('session-status').textContent=e.message;}
        finally{restore.disabled=false;}
      };
      const remove=document.createElement('button');remove.className='outline-button';remove.textContent='Delete';remove.setAttribute('aria-label','Delete session '+session.name);remove.onclick=()=>{sessions=sessions.filter(s=>s.id!==session.id);const ok=safeSave('crowded-sessions-v1',sessions);renderSessions();get('session-status').textContent=ok?'Session deleted.':'Removed for now; storage is unavailable.';};
      row.append(details,restore,remove);list.append(row);
    });
  }
  get('session-form').onsubmit=e=>{
    e.preventDefault();const name=get('session-name').value.trim();if(!name)return;
    const tabs=workspaceTabs.filter(t=>t.url).map(t=>({url:t.url,title:t.title}));
    if(!tabs.length){get('session-status').textContent='Open a website first. Empty tabs are not saved.';return;}
    if(sessions.length>=8){get('session-status').textContent='You can save 8 sessions. Delete one to make room.';return;}
    sessions.unshift({id:crypto.randomUUID(),name,tabs});
    const ok=safeSave('crowded-sessions-v1',sessions);renderSessions();get('session-name').value='';get('session-status').textContent=ok?'Saved '+tabs.length+' tabs.':'Available this session only; browser storage is unavailable.';
  };
  function quickEntries(){
    const action=(name,run)=>({name,detail:'Action',run});
    return [
      action('New tab',newBrowserTab),action('Open music',()=>showPage('music')),action('Open AI',()=>showPage('ai')),action('Open settings',()=>showPage('settings')),action('Open tools',openTools),action('Reopen closed tab',()=>$('reopen-tab').click()),
      ...workspaceTabs.map(t=>({name:t.title,detail:'Open tab'+(t.url?' · '+new URL(t.url).hostname:''),run:()=>activateTab(t.id)})),
      ...bookmarks.map(b=>({name:b.name,detail:'Bookmark · '+new URL(b.url).hostname,run:()=>browse(b.url)}))
    ];
  }
  let quickMatches=[];
  const runQuick=item=>{get('quick-dialog').close();item.run();};
  function renderQuick(){
    const q=get('quick-input').value.trim().toLowerCase();
    quickMatches=quickEntries().filter(item=>(item.name+' '+item.detail).toLowerCase().includes(q)).slice(0,16);
    get('quick-results').replaceChildren();
    if(!quickMatches.length){const p=document.createElement('p');p.className='dialog-intro';p.textContent='No matches. Try a bookmark name or “music”.';get('quick-results').append(p);}
    quickMatches.forEach(item=>{const button=document.createElement('button');button.className='quick-result';const name=document.createElement('strong'),detail=document.createElement('small');name.textContent=item.name;detail.textContent=item.detail;button.append(name,detail);button.onclick=()=>runQuick(item);get('quick-results').append(button);});
  }
  function openQuick(){if(document.querySelector('dialog[open]'))return;get('quick-input').value='';renderQuick();get('quick-dialog').showModal();get('quick-input').focus();}
  get('quick-open').onclick=openQuick;get('quick-input').oninput=renderQuick;
  get('quick-input').onkeydown=e=>{if(e.key==='Enter'&&!e.isComposing&&quickMatches[0]){e.preventDefault();runQuick(quickMatches[0]);}if(e.key==='ArrowDown'){e.preventDefault();get('quick-results').querySelector('button')?.focus();}};
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openQuick();}});
})();
