import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Crowded Browser",
  description: "Browse, listen, and chat with Crowded AI.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
