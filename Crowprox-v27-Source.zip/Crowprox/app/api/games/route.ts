const origin='https://gn-math.dev';
let cached:{expires:number,games:unknown[]}|undefined;
export function gameURL(value:unknown,cover:string,html:string){
 if(typeof value!=='string')return null;
 try{const u=new URL(value.replaceAll('{COVER_URL}',cover).replaceAll('{HTML_URL}',html),origin);return u.origin===origin&&u.pathname.startsWith('/s/')&&!u.username&&!u.password?u.href:null;}catch{return null;}
}
export async function GET(){
 if(cached&&cached.expires>Date.now())return Response.json({games:cached.games},{headers:{'Cache-Control':'public, max-age=300'}});
 try{
  const response=await fetch(origin+'/',{signal:AbortSignal.timeout(10000)});if(!response.ok)throw new Error('Site unavailable');const page=await response.text();
  const config=(name:string)=>page.match(new RegExp('(?:let|const)\\s+'+name+'\\s*=\\s*["\']([^"\']+)["\']'))?.[1];
  const zones=config('zonesURL'),cover=config('coverURL'),html=config('htmlURL');if(!zones||!cover||!html)throw new Error('Catalog moved');
  const catalogURL=gameURL(zones,cover,html);if(!catalogURL)throw new Error('Invalid catalog');
  const r=await fetch(catalogURL,{signal:AbortSignal.timeout(10000)});if(!r.ok)throw new Error('Catalog unavailable');const data=await r.json();if(!Array.isArray(data))throw new Error('Invalid catalog');
  const games=data.filter((g:any)=>g&&Number.isInteger(g.id)&&g.id>=0&&typeof g.name==='string').map((g:any)=>({id:String(g.id),name:g.name.slice(0,140),author:typeof g.author==='string'?g.author.slice(0,120):'',url:gameURL(g.url,cover,html),cover:gameURL(g.cover,cover,html)})).filter(g=>g.url&&new URL(g.url).pathname.endsWith('.html')).slice(0,1500);
  cached={expires:Date.now()+300000,games};return Response.json({games},{headers:{'Cache-Control':'public, max-age=300'}});
 }catch{return Response.json({error:'GN-Math could not be reached. Try again shortly.'},{status:503});}
}
