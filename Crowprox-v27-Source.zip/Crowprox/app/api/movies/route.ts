import picks from './catalog.json';
const cache=new Map<string,{until:number,movies:unknown[]}>();
async function wiki(params:Record<string,string>){const u=new URL('https://www.wikidata.org/w/api.php');u.search=new URLSearchParams({...params,format:'json'});const r=await fetch(u,{signal:AbortSignal.timeout(12000),headers:{'User-Agent':'Crowprox/1.0 (movie metadata search)'}});if(!r.ok)throw Error('Movie search is temporarily unavailable.');return r.json() as Promise<any>;}
export async function GET(request:Request){
 const q=(new URL(request.url).searchParams.get('q')||'').trim().slice(0,100);if(!q)return Response.json({movies:picks,label:'Recent picks'});
 const cached=cache.get(q.toLowerCase());if(cached&&cached.until>Date.now())return Response.json({movies:cached.movies});
 try{
 const data=await wiki({action:'wbsearchentities',search:q,language:'en',limit:'30'});const ids=(data.search||[]).map((x:any)=>x.id).filter((id:string)=>/^Q\d+$/.test(id));
 if(!ids.length)return Response.json({movies:[]});
 const details=await wiki({action:'wbgetentities',ids:ids.join('|'),props:'claims|labels|descriptions',languages:'en'});
 const movies=ids.map((key:string)=>{const e=details.entities?.[key];if(!e)return null;const claim=(p:string)=>e.claims?.[p]?.find((c:any)=>c.rank!=='deprecated'&&c.mainsnak?.datavalue)?.mainsnak.datavalue.value;const id=claim('P4947');if(typeof id!=='string'||!/^\d+$/.test(id))return null;const date=claim('P577')?.time?.replace(/^\+/,'');if(date&&date.slice(0,10)>new Date().toISOString().slice(0,10))return null;return{id,title:e.labels?.en?.value||q,year:date?.slice(0,4)||'',description:e.descriptions?.en?.value||'',poster:'/api/movies/poster?id='+id};}).filter(Boolean);
 if(cache.size>100)cache.delete(cache.keys().next().value!);cache.set(q.toLowerCase(),{until:Date.now()+600000,movies});return Response.json({movies});
 }catch(e){return Response.json({error:e instanceof Error&&e.name==='TimeoutError'?'Movie search took too long. Try again.':e instanceof Error?e.message:'Movie search failed.'},{status:503});}
}
