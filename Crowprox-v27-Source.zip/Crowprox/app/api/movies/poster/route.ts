const images=new Map<string,string>();
export async function GET(request:Request){
 const id=new URL(request.url).searchParams.get('id')||'';if(!/^\d{1,10}$/.test(id))return new Response(null,{status:400});
 try{let image=images.get(id);if(!image){const r=await fetch('https://www.themoviedb.org/movie/'+id,{signal:AbortSignal.timeout(10000)});if(!r.ok)return new Response(null,{status:404});const html=await r.text();image=html.match(/<meta property="og:image" content="([^"]+)"/)?.[1];if(!image)return new Response(null,{status:404});const u=new URL(image);if(u.protocol!=='https:'||!['media.themoviedb.org','image.tmdb.org'].includes(u.hostname))return new Response(null,{status:404});if(images.size>300)images.delete(images.keys().next().value!);images.set(id,image);}return new Response(null,{status:302,headers:{Location:image,'Cache-Control':'public, max-age=86400'}});}catch{return new Response(null,{status:404});}
}
