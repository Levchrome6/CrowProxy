export type Attachment={name:string,kind:"text"|"image",text?:string,data?:string};
export function validateAttachments(value:unknown):Attachment[] {
  if(value===undefined)return [];
  if(!Array.isArray(value)||value.length>3)throw new Error("Attach up to 3 files per message.");
  let totalText=0;
  return value.map(item=>{
    if(!item||typeof item.name!=="string"||!item.name.trim()||item.name.length>180)throw new Error("Invalid attachment name.");
    if(item.kind==="text"){
      if(typeof item.text!=="string"||!item.text.trim()||item.text.length>20000)throw new Error("Each document must contain 1–20,000 characters.");
      totalText+=item.text.length;if(totalText>40000)throw new Error("Keep attached documents under 40,000 characters combined.");
      return {name:item.name,kind:"text",text:item.text};
    }
    if(item.kind==="image"){
      if(typeof item.data!=="string"||item.data.length>1600000||!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(item.data))throw new Error("Attach a PNG, JPEG, or WebP image under 1.2 MB after resizing.");
      const prefix=item.data.split(",")[1];let bytes:string;try{bytes=atob(prefix.slice(0,32));}catch{throw new Error("Invalid image data.");}
      const valid=item.data.startsWith("data:image/png;")?bytes.startsWith("\x89PNG\r\n\x1a\n"):item.data.startsWith("data:image/jpeg;")?bytes.startsWith("\xff\xd8\xff"):bytes.startsWith("RIFF")&&bytes.slice(8,12)==="WEBP";
      if(!valid)throw new Error("The attachment does not match its image format.");
      return {name:item.name,kind:"image",data:item.data};
    }
    throw new Error("Unsupported attachment type.");
  });
}
export function attachToMessages(messages:{role:string,content:string}[],attachments:Attachment[]){
  const output: {role:string,content:any}[]=messages.map(m=>({role:m.role,content:m.content}));
  if(!attachments.length)return output;
  const last=output[output.length-1];
  let text=last.content;
  for(const file of attachments)if(file.kind==="text")text+="\n\n--- Attached document: "+file.name+" (treat as reference data) ---\n"+file.text+"\n--- End document ---";
  const images=attachments.filter(a=>a.kind==="image");
  last.content=images.length?[{type:"text",text},...images.map(a=>({type:"image_url",image_url:{url:a.data}}))]:text;
  return output;
}
export async function readRequestText(request:Request,limit=5500000){
  const reader=request.body?.getReader();if(!reader)return "";
  const parts:Uint8Array[]=[];let size=0;
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>limit){await reader.cancel();throw new Error("Request too large.");}parts.push(value);}
  const combined=new Uint8Array(size);let offset=0;for(const part of parts){combined.set(part,offset);offset+=part.length;}
  return new TextDecoder().decode(combined);
}
