const cache=new Map<string,{expires:number,body:unknown}>();
export function normalizeApple(t:any){
 if(t?.kind!=='song'||!Number.isSafeInteger(t.trackId)||typeof t.trackViewUrl!=='string')return null;
 let url:URL;try{url=new URL(t.trackViewUrl);}catch{return null;}
 if(url.protocol!=='https:'||url.hostname!=='music.apple.com')return null;
 url.searchParams.delete('uo');
 // Metadata only. Playback and artwork remain inside Apple's official player.
 return {id:'apple'+t.trackId,provider:'apple',catalog:true,name:String(t.trackName||'Untitled').slice(0,200),artist:String(t.artistName||'Unknown artist').slice(0,120),album:String(t.collectionName||'').slice(0,160),genre:String(t.primaryGenreName||''),duration:Math.round((Number(t.trackTimeMillis)||0)/1000),permalink:url.href,artwork:null};
}
export async function GET(request:Request){
 const q=(new URL(request.url).searchParams.get('q')||'').trim().slice(0,100);
 if(!q)return Response.json({tracks:[],nextOffset:null,source:'Apple Music'});
 const cached=cache.get(q.toLowerCase());if(cached&&cached.expires>Date.now())return Response.json(cached.body,{headers:{'Cache-Control':'public, max-age=300'}});
 try{
 const url=new URL('https://itunes.apple.com/search');for(const [k,v]of Object.entries({term:q,entity:'song',media:'music',country:'US',limit:'50'}))url.searchParams.set(k,v);
 const r=await fetch(url,{signal:AbortSignal.timeout(12000)});if(!r.ok)throw new Error('Unavailable');const d=await r.json() as {results?:unknown[]};if(!Array.isArray(d.results))throw new Error('Invalid catalog');
 const body={tracks:d.results.map(normalizeApple).filter(Boolean),nextOffset:null,source:'Apple Music'};if(cache.size>=100)cache.delete(cache.keys().next().value!);cache.set(q.toLowerCase(),{expires:Date.now()+300000,body});return Response.json(body,{headers:{'Cache-Control':'public, max-age=300'}});
 }catch{return Response.json({error:'Apple Music search is temporarily unavailable. Try again or switch to Audius.'},{status:503});}
}
