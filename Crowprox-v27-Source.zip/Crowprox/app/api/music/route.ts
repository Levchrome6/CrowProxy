const cache=new Map<string,{expires:number,body:unknown}>();
const genres=new Set(['Electronic','Hip-Hop/Rap','Pop','House','Lo-Fi','Ambient','Rock','Jazz','Classical','R&B/Soul']);
const httpsURL=(value:unknown)=>{try{const u=new URL(String(value));return u.protocol==='https:'&&!u.username&&!u.password?u.href:null;}catch{return null;}};
export function normalizeTrack(track:any){
 if(!track||!track.is_streamable||track.is_available===false||track.is_stream_gated||track.is_unlisted||track.is_delete||track.user?.is_deactivated||track.allowed_api_keys?.length||typeof track.id!=='string'||! /^[a-zA-Z0-9]{1,40}$/.test(track.id))return null;
 return {id:track.id,name:String(track.title||'Untitled').slice(0,200),artist:String(track.user?.name||'Unknown artist').slice(0,120),artwork:httpsURL(track.artwork?.['480x480']),duration:Math.max(0,Number(track.duration)||0),genre:String(track.genre||''),permalink:typeof track.permalink==='string'&&track.permalink.startsWith('/')&&!track.permalink.startsWith('//')?'https://audius.co'+track.permalink:'https://audius.co',url:'https://api.audius.co/v1/tracks/'+track.id+'/stream?app_name=CrowdedBrowser',catalog:true};
}
export async function GET(request:Request){
 const params=new URL(request.url).searchParams,q=(params.get('q')||'').trim().slice(0,100),genre=params.get('genre')||'',offset=Number(params.get('offset')||0);
 if(!Number.isInteger(offset)||offset<0||offset>960||genre&&!genres.has(genre))return Response.json({error:'Invalid music search.'},{status:400});
 const upstream=new URL('https://api.audius.co/v1/tracks/'+(q?'search':'trending'));upstream.searchParams.set('app_name','CrowdedBrowser');upstream.searchParams.set('limit','40');upstream.searchParams.set('offset',String(offset));if(q)upstream.searchParams.set('query',q);if(genre)upstream.searchParams.set('genre',genre);
 const key=upstream.href,cached=cache.get(key);if(cached&&cached.expires>Date.now())return Response.json(cached.body,{headers:{'Cache-Control':'public, max-age=60'}});
 try{
  const response=await fetch(upstream,{signal:AbortSignal.timeout(12000),headers:{Accept:'application/json'}});
  if(!response.ok)return Response.json({error:response.status===429?'The music catalog is busy. Try again shortly.':'The music catalog is temporarily unavailable. Try again.'},{status:503});
  const data=await response.json() as {data?:unknown[]};if(!Array.isArray(data.data))throw new Error('Invalid catalog');
  const tracks=data.data.map(normalizeTrack).filter(Boolean),body={tracks,nextOffset:data.data.length===40&&offset<960?offset+40:null,source:'Audius'};
  if(cache.size>=100)cache.delete(cache.keys().next().value!);cache.set(key,{expires:Date.now()+60000,body});
  return Response.json(body,{headers:{'Cache-Control':'public, max-age=60'}});
 }catch{return Response.json({error:'Could not reach the music catalog. Please retry.'},{status:503});}
}
