import {env} from 'cloudflare:workers';
import {availableModels} from './catalog';
export async function GET(){const key=(env as unknown as {GROQ_API_KEY?:string}).GROQ_API_KEY;if(!key)return Response.json({models:[],error:'AI is not configured.'},{status:503});try{return Response.json({models:await availableModels(key)},{headers:{'Cache-Control':'private, max-age=60'}});}catch{return Response.json({models:[],error:'Model list is temporarily unavailable. Auto is still available.'},{status:503});}}
