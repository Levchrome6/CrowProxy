export const supported:Record<string,{label:string,vision:boolean}>={
 'openai/gpt-oss-120b':{label:'GPT-OSS 120B',vision:false},
 'openai/gpt-oss-20b':{label:'GPT-OSS 20B',vision:false},
 'llama-3.3-70b-versatile':{label:'Llama 3.3 70B',vision:false},
 'llama-3.1-8b-instant':{label:'Llama 3.1 8B',vision:false},
 'qwen/qwen3.8-27b':{label:'Qwen 3.8 27B · images',vision:true},
 'meta-llama/llama-4-scout-17b-16e-instruct':{label:'Llama 4 Scout · images',vision:true},
 'meta-llama/llama-4-maverick-17b-128e-instruct':{label:'Llama 4 Maverick · images',vision:true},
 'qwen/qwen3-vl-32b-instruct':{label:'Qwen3 VL · images',vision:true},
 'minimaxai/minimax-m2.7':{label:'MiniMax M2.7',vision:false}
};
let cache:{expires:number,models:{id:string,label:string,vision:boolean}[]}|undefined;
export async function availableModels(key:string){
 if(cache&&cache.expires>Date.now())return cache.models;
 const r=await fetch('https://api.groq.com/openai/v1/models',{headers:{Authorization:'Bearer '+key},signal:AbortSignal.timeout(7000)});if(!r.ok)throw new Error('Models unavailable');
 const d=await r.json() as {data?:{id:string,active?:boolean}[]};const active=new Set((d.data||[]).filter(m=>m.active!==false).map(m=>m.id));
 const models=Object.entries(supported).filter(([id])=>active.has(id)).map(([id,info])=>({id,...info}));cache={models,expires:Date.now()+300000};return models;
}
